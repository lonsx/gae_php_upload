﻿#!/usr/bin/env python
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#



"""Convenience wrapper for starting an appengine tool."""


import os
import re
import sys


BANNER = '''\
===============================================================
 Google GAE PHP服务部署程序, 开始上传PHP 应用文件夹
===============================================================

请使用参数 '-R update DIR\\'来上传您的PHP应用，使用'-R rollback DIR\\'来回滚更新。
请确保您的应用名已申请可用PHP，未申请可去 https://gaeforphp.appspot.com/ 申请。
'''

FOOTER = '''\
操作成功，现在您可访问 appname.appspot.com 查看效果，谢谢。按回车键退出程序。
'''


#DIR_PATH = os.path.dirname(os.path.abspath(__file__))
import module_locator
DIR_PATH = module_locator.module_path()


#SCRIPT_DIR = os.path.join('./','google', 'appengine', 'tools')

if DIR_PATH.endswith('.zip'):
	DIR_PATH = os.path.dirname(DIR_PATH)
os.chdir(DIR_PATH)


EXTRA_PATHS = [
  DIR_PATH,
  '.',
#   __file__,
]



def fix_sys_path(extra_extra_paths=()):
  """Fix the sys.path to include our extra paths."""
  extra_paths = EXTRA_PATHS[:]
  extra_paths.extend(extra_extra_paths)
  sys.path = extra_paths + sys.path
  


#def run_file( globals_, script_dir=SCRIPT_DIR):
def run_file( globals_):
  """Execute the file at the specified path with the passed-in globals."""
  #script_name = os.path.basename(file_path)
  #script_name = 'appcfg.py'

  extra_extra_paths = []
  fix_sys_path(extra_extra_paths)


  if 'google' in sys.modules:
    del sys.modules['google']
  
  import google.appengine.tools.appengine_rpc
  google.appengine.tools.appengine_rpc.HttpRpcServer.DEFAULT_COOKIE_FILE_PATH = './.appcfg_cookies'
  import google.appengine.tools.appcfg
  google.appengine.tools.appcfg.main(sys.argv)
  
  #script_path = os.path.join(script_dir, script_name)
  #execfile(script_path, globals_)


if __name__ == '__main__':
   try:
        print BANNER.decode('utf-8').encode(sys.getfilesystemencoding(), 'replace')
        run_file(globals())
        print
        print FOOTER.decode('utf-8').encode(sys.getfilesystemencoding(), 'replace')
        raw_input()
   except KeyboardInterrupt:
        pass
﻿# If you create a module with the following code and put it in the same directory as your main script,
#then the main script can import the module and use that to locate itself.
#When you meet 'NameError: global name '__file__' is not defined'
import sys
import os

def we_are_frozen():
    # All of the modules are built-in to the interpreter, e.g., by py2exe
    return hasattr(sys, "frozen")

def module_path():
    encoding = sys.getfilesystemencoding()
    if we_are_frozen():
        return os.path.dirname(unicode(sys.executable, encoding))
    return os.path.dirname(unicode(__file__, encoding))